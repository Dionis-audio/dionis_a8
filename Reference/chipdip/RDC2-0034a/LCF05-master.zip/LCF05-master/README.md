# LCF05
2nd Order L-C Output Filter for Class D amplifier
<p><a https://static.chipdip.ru/lib/016/DOC004016706.jpg" class="galery"><img src="https://static.chipdip.ru/lib/016/DOC004016706.jpg" alt="3d model"></a></p>
<p><a https://static.chipdip.ru/lib/017/DOC004017199.png" class="galery"><img src="https://static.chipdip.ru/lib/017/DOC004017199.png" alt="scheme"></a></p>
